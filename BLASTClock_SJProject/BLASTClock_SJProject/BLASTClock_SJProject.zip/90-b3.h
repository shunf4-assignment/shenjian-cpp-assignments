/* 1652270 �����2�� ��˴ */
/*BLASTClock_SJProject - 90-b3.h*/
#pragma once
#include "cmd_console_tools.h"
#include <iostream>
#include <iomanip>
#include <cstdio>

using namespace std;

/*Const Numbers*/
const int fontCommSize = 1;
const int windowClockW = 1200;
const int windowClockH = 400;
const int colorCommBack = COLOR_BLACK;
const int colorCommFore = COLOR_WHITE;
const int thickSecond = 1;
const int thickMinute = 2;
const int thickHour = 4;
const int figreStrokeNum = 7;
const double handlenSecond = 0.9;
const double handlenMinute = 0.75;
const double handlenHour = 0.4;
const double lenGrad = 0.08;

const double pi = 3.14159265;
const double ratioCharWidthOverHeight = 0.5;

/*Const Strings*/
const wchar_t * const fontCommName = L"������";


/*Structs*/
struct Clock
{
	COORD centerPos;
	short radius;
	int hour;
	int min;
	int sec;
	int colorFore;
	int colorBack;
};

struct Figure
{
	COORD startPos;
	short widthX;
	short widthY;
	short thickX;
	short thickY;
	short n;
};

struct Stroke
{
	double sxr;  //startXRatio
	double syr;  //startYRatio
	double exr;  //end...
	double eyr;
};

struct EClock
{
	COORD startPos;
	short widthX;
	short widthY;
	short thickX;
	short thickY;
	short gap;
	short spaceBetw;
	bool havesec;
	int hour;
	int min;
	int sec;
};

const struct Stroke patFigures[10][figreStrokeNum] =
{
	{ { 0,0,1,0 },{ 0,0,0,1 },{ 1,0,1,1 },{ 0,1,1,1 },{ 0,0,0,0 },{ 0,0,0,0 },{ 0,0,0,0 } },
	{ { 1,0,1,1 },{ 0,0,0,0 },{ 0,0,0,0 },{ 0,0,0,0 },{ 0,0,0,0 },{ 0,0,0,0 },{ 0,0,0,0 } },
	{ { 0,0,1,0 },{ 1,0,1,0.5 },{ 1,0.5,0,0.5 },{ 0,0.5,0,1 },{ 0,1,1,1 },{ 0,0,0,0 } ,{ 0,0,0,0 } },
	{ { 0,0,1,0 },{ 1,0,1,0.5 },{ 1,0.5,0,0.5 },{ 1,0.5,1,1 },{ 0,1,1,1 },{ 0,0,0,0 } ,{ 0,0,0,0 } },
	{ { 0,0,0,0.5 },{ 0,0.5,1,0.5 },{ 1,0,1,1 },{ 0,0,0,0 },{ 0,0,0,0 },{ 0,0,0,0 } ,{ 0,0,0,0 } },
	{ { 1,0,0,0 },{ 0,0,0,0.5 },{ 0,0.5,1,0.5 },{ 1,0.5,1,1 },{ 1,1,0,1 },{ 0,0,0,0 } ,{ 0,0,0,0 } },
	{ { 1,0,0,0 },{ 0,0,0,0.5 },{ 0,0.5,1,0.5 },{ 1,0.5,1,1 },{ 1,1,0,1 },{ 0,1,0,0.5 } ,{ 0,0,0,0 } },
	{ { 0,0,1,0 },{ 1,0,1,1 },{ 0,0,0,0 } ,{ 0,0,0,0 } ,{ 0,0,0,0 } ,{ 0,0,0,0 } ,{ 0,0,0,0 } },
	{ { 0,0,1,0 },{ 0,0,0,1 },{ 0,0.5,1,0.5 } ,{ 1,0,1,1 } ,{ 0,1,1,1 } ,{ 0,0,0,0 } ,{ 0,0,0,0 } },
	{ { 0,0,1,0 },{ 0,0,0,0.5 },{ 0,0.5,1,0.5 } ,{ 1,0,1,1 } ,{ 0,1,1,1 } ,{ 0,0,0,0 } ,{ 0,0,0,0 } }
};

/*Handles*/
const HANDLE hout = GetStdHandle(STD_OUTPUT_HANDLE); //ȡ��׼����豸��Ӧ�ľ��
const HANDLE hin = GetStdHandle(STD_INPUT_HANDLE);  //ȡ��׼�����豸��Ӧ�ľ��

int sgn(int x);
int sgn(double x);

/*Graphics Func*/
void initClock();
void initMenu();
void setGlobalColor(int back, int fore);
void drawCircleAtUpperLeft(COORD pos, int radius);
void drawCircleAtCenter(COORD pos, int radius);
void drawLineByPoint(COORD point1, COORD point2, int widthX, int widthY);
void drawPoint(COORD point, int widthX, int widthY);