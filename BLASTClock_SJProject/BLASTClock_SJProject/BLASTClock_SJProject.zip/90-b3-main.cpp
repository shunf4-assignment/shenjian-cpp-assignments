/* 1652270 �����2�� ��˴ */
/*BLASTClock_SJProject - 90-b3-main.cpp*/
#include "90-b3.h"

void updateHourHand(Clock &c, SYSTEMTIME t)
{
	double angle;
	double handLen;
	handLen = c.radius * handlenHour;
	if (t.wHour != c.hour)
	{
		angle = 2 * pi / 12 * c.hour + pi / 6 * c.min / 60 + pi / 6 / 60 * c.sec / 60;
		setcolor(hout, c.colorBack, c.colorBack);
		drawLineByPoint(c.centerPos, { short(round(c.centerPos.X + (handLen * sin(angle)) / ratioCharWidthOverHeight)), short(round(c.centerPos.Y - handLen * cos(angle))) }, thickHour, thickHour);
	}
	
	angle = 2 * pi / 12 * t.wHour + pi / 6 * t.wMinute / 60 + pi / 6 / 60 * t.wSecond / 60;
	setcolor(hout, c.colorFore, c.colorFore);
	drawLineByPoint(c.centerPos, { short(round(c.centerPos.X + (handLen * sin(angle)) / ratioCharWidthOverHeight)), short(round(c.centerPos.Y - handLen * cos(angle))) }, thickHour, thickHour);
}

void updateMinuteHand(Clock &c, SYSTEMTIME t)
{
	double angle;
	double handLen;
	handLen = c.radius * handlenMinute;
	if (t.wMinute != c.min)
	{
		angle = 2 * pi / 60 * c.min;
		setcolor(hout, c.colorBack, c.colorBack);
		drawLineByPoint(c.centerPos, { short(round(c.centerPos.X + (handLen * sin(angle)) / ratioCharWidthOverHeight)), short(round(c.centerPos.Y - handLen * cos(angle))) }, thickMinute, thickMinute);
	}
	
	angle = 2 * pi / 60 * t.wMinute;
	setcolor(hout, c.colorFore, c.colorFore);
	drawLineByPoint(c.centerPos, { short(round(c.centerPos.X + (handLen * sin(angle)) / ratioCharWidthOverHeight)), short(round(c.centerPos.Y - handLen * cos(angle))) }, thickMinute, thickMinute);
}

void updateSecondHand(Clock &c, SYSTEMTIME t)
{
	double angle;
	double handLen;

	angle = 2 * pi / 60 * c.sec;
	handLen= c.radius * handlenSecond;
	setcolor(hout, c.colorBack, c.colorBack);
	drawLineByPoint(c.centerPos, { short(round(c.centerPos.X + (handLen * sin(angle)) / ratioCharWidthOverHeight)), short(round(c.centerPos.Y - handLen * cos(angle))) }, thickSecond, thickSecond);
	angle = 2 * pi / 60 * t.wSecond;
	setcolor(hout, c.colorFore, c.colorFore);
	drawLineByPoint(c.centerPos, { short(round(c.centerPos.X + (handLen * sin(angle)) / ratioCharWidthOverHeight)), short(round(c.centerPos.Y - handLen * cos(angle))) }, thickSecond, thickSecond);
}

void getTimeToHMS(SYSTEMTIME st, Clock &c)
{
	c.hour = st.wHour;
	c.min = st.wMinute;
	c.sec = st.wSecond;
}

void getTimeToHMS(SYSTEMTIME st, EClock &c)
{
	c.hour = st.wHour;
	c.min = st.wMinute;
	c.sec = st.wSecond;
}

void drawGrad(Clock &c)
{
	double handLen = c.radius * (1 - lenGrad);
	double angle;

	setcolor(hout, c.colorFore, c.colorFore);
	for (int i = 0; i < 12; i++)
	{
		angle = 2 * pi / 12 * i;

		drawLineByPoint({ short(round(c.centerPos.X + (c.radius * sin(angle)) / ratioCharWidthOverHeight)), short(round(c.centerPos.Y - c.radius * cos(angle))) }, { short(round(c.centerPos.X + (handLen * sin(angle)) / ratioCharWidthOverHeight)), short(round(c.centerPos.Y - handLen * cos(angle))) }, thickSecond, thickSecond);
	}
}

void drawFigure(Figure &f)
{
	double totalWidth = f.widthX - f.thickX;
	double totalHeight = f.widthY - f.thickY;
	double strokeStartX;
	double strokeStartY;
	double strokeEndX;
	double strokeEndY;
	for (const Stroke(*p) = patFigures[f.n]; p->exr + p->eyr + p->sxr + p->syr; p++)
	{
		strokeStartX = f.startPos.X + totalWidth * p->sxr ;
		strokeStartY = f.startPos.Y + totalHeight * p->syr;
		strokeEndX = f.startPos.X + totalWidth * p->exr;
		strokeEndY = f.startPos.Y + totalHeight * p->eyr;
		drawLineByPoint({ short(round(strokeStartX)),short(round(strokeStartY)) }, { short(round(strokeEndX)),short(round(strokeEndY)) }, f.thickX, f.thickY);
	}
}

void clearAll(COORD leftTop, COORD rightBottom)
{
	short unit = sgn(rightBottom.Y - leftTop.Y);
	for (short i = leftTop.Y; i <= rightBottom.Y; i += unit)
	{
		gotoxy(hout, leftTop.X, i);
		cout << setw(rightBottom.X - leftTop.X + 1) << "";
	}
	
}

void drawTwoDigit(Figure &f, COORD startPos,int widthX, int gap, short num1, short num2)
{
	f.n = num1;
	f.startPos = startPos;
	drawFigure(f);
	f.n = num2;
	f.startPos = { short(startPos.X + widthX + gap), startPos.Y };
	drawFigure(f);
}

void drawEClock(EClock &e, SYSTEMTIME st, bool force = 0)
{
	short count = e.havesec ? (6) : (4);
	short totalW = count * e.gap +  (count + 1) *e.widthX;
	short totalH = e.widthY;
	Figure f;
	f.thickX = e.thickX;
	f.thickY = e.thickY;
	f.widthX = e.widthX;
	f.widthY = e.widthY;
	//setcolor(hout, colorCommBack, colorCommBack);
	//clearAll({ e.startPos.X, e.startPos.Y }, { e.startPos.X + totalW - 1, e.startPos.Y + totalH - 1 });
	//setcolor(hout, colorCommFore, colorCommFore);

	if (st.wHour != e.hour || force)
	{
		if (!force)
		{
			setcolor(hout, colorCommBack, colorCommBack);
			drawTwoDigit(f, e.startPos, e.widthX, e.gap, e.hour / 10, e.hour % 10);
			setcolor(hout, colorCommFore, colorCommFore);
		}
		drawTwoDigit(f, e.startPos, e.widthX, e.gap, st.wHour / 10, st.wHour % 10);
	}

	if (st.wMinute != e.min || force)
	{
		if (!force)
		{
			setcolor(hout, colorCommBack, colorCommBack);
			drawTwoDigit(f, { e.startPos.X + e.widthX * 2 + e.gap * 1 + e.spaceBetw, e.startPos.Y }, e.widthX, e.gap, e.min / 10, e.min % 10);
			setcolor(hout, colorCommFore, colorCommFore);
		}
		drawTwoDigit(f, { e.startPos.X + e.widthX * 2 + e.gap * 1 + e.spaceBetw, e.startPos.Y }, e.widthX, e.gap, st.wMinute / 10, st.wMinute % 10);
	}

	if (e.havesec && st.wSecond != e.sec || force)
	{
		if (!force)
		{
			setcolor(hout, colorCommBack, colorCommBack);
			drawTwoDigit(f, { e.startPos.X + e.widthX * 4 + e.gap * 2 + e.spaceBetw * 2, e.startPos.Y }, e.widthX, e.gap, e.sec / 10, e.sec % 10);
			setcolor(hout, colorCommFore, colorCommFore);
		}
		drawTwoDigit(f, { e.startPos.X + e.widthX * 4 + e.gap * 2 + e.spaceBetw * 2, e.startPos.Y }, e.widthX, e.gap, st.wSecond / 10, st.wSecond % 10);
	}
	
}

void clockMain()
{
	initClock();
	Clock c;
	EClock e;
	SYSTEMTIME st;
	c.centerPos = { 190, 120 };
	c.radius = 80;
	c.colorBack = colorCommBack;
	c.colorFore = colorCommFore;
	e.startPos = { 400, 80 };
	e.gap = 20;
	e.spaceBetw = 60;
	e.thickX = 6, e.thickY = 5;
	e.widthX = 60;
	e.widthY = 60;
	e.havesec = true;
	GetLocalTime(&st);
	getTimeToHMS(st, c);
	drawCircleAtCenter(c.centerPos, c.radius);
	drawGrad(c);
	drawEClock(e, st, true);
	while (true)
	{
		if (c.sec != st.wSecond)
		{
			updateSecondHand(c, st);
			updateMinuteHand(c, st);
			updateHourHand(c, st);
			drawEClock(e, st, 0);
		}
		
		getTimeToHMS(st, c);
		getTimeToHMS(st, e);

		Sleep(200);
		GetLocalTime(&st);
		
	}
}

int main()
{
	
	//cout << "fuck" << endl;
	
	//drawCircleAtCenter({ 190,110 }, 80);
	clockMain();
	/*initClock();

	Figure f;
	f.n = 3;
	f.startPos = { 30,30 };
	f.thickX = 6;
	f.thickY = 4;
	f.widthY = 30;
	f.widthX = 60;
	setcolor(hout, COLOR_WHITE, COLOR_WHITE);
	for (int i = 0; i < 10; i++)
	{
		f.n = i;
		f.startPos = { short(f.startPos.X + 75), f.startPos.Y };
		drawFigure(f);

	}*/
	return 0;
}
