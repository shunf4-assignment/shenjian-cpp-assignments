/*7772334 �Է� 3��*/
#include <iostream>
using namespace std;
int main()
{
	cout<<"This"<<"is";
	cout<<"a"<<"C++";
	cout<<"program."<<endl;
	return 0;
}
/*���ThisisaC++program.��仰*/